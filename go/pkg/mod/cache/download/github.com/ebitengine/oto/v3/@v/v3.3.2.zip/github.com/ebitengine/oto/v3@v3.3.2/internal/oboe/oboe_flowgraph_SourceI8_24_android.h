/*
 * Copyright 2023 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef FLOWGRAPH_SOURCE_I8_24_H
#define FLOWGRAPH_SOURCE_I8_24_H

#include <stdint.h>

#include "oboe_flowgraph_FlowGraphNode_android.h"

namespace FLOWGRAPH_OUTER_NAMESPACE::flowgraph {

class SourceI8_24 : public FlowGraphSourceBuffered {
public:
    explicit SourceI8_24(int32_t channelCount);
    ~SourceI8_24() override = default;

    int32_t onProcess(int32_t numFrames) override;

    const char *getName() override {
        return "SourceI8_24";
    }
private:
    static constexpr float kScale = 1.0 / (1UL << 23);
};

} /* namespace FLOWGRAPH_OUTER_NAMESPACE::flowgraph */

#endif //FLOWGRAPH_SOURCE_I8_24_H
